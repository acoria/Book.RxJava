const app = require('express')();
const http = require('http');
const theHttpServer = http.Server(app);
const path = require('path');
var webSocketServer = require('websocket').server;


const PORT = process.env.PORT || 3000;
const INDEX = path.join(__dirname, 'index.html');

var lastMessages = [];

theHttpServer.listen(PORT, function(){
  console.log('listening on *:' + PORT);
});

//Routing:
app.get('/', function(req, res){
  res.sendFile(INDEX);
});

app.get('/messages', function(req, res) {
  res.json(lastMessages);
});



//WebSocket server:
var wsServer = new webSocketServer({
  // WebSocket server is tied to a HTTP server. WebSocket
  // request is just an enhanced HTTP request. For more info 
  // http://tools.ietf.org/html/rfc6455#page-6
  httpServer: theHttpServer
});
// This callback function is called every time someone
// tries to connect to the WebSocket server
wsServer.on('request', function(request) {
  console.log((new Date()) + ' Connection from origin ' + request.origin + '.');
  // accept connection - you should check 'request.origin' to
  // make sure that client is connecting from your website
  // (http://en.wikipedia.org/wiki/Same_origin_policy)
  var connection = request.accept(null, request.origin); 
  console.log((new Date()) + ' Connection accepted.');
  
  //send back the sent message
  connection.on('message', function(message) {
	//add to cache
    lastMessages.push(message.utf8Data);
	
	if (message.type === 'utf8') { // accept only text
		console.log('message received: ' + message.utf8Data);	
		connection.sendUTF(message.utf8Data);
           
    } else { // log the message
        console.log((new Date()) + ' notUtf8 ' + message.utf8Data);        
    }
  });
  connection.on('close', function(connection) {
      console.log((new Date()) + " Peer "
          + connection.remoteAddress + " disconnected.");
  });
});