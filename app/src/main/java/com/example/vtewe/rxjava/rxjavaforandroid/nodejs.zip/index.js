var webSocketsServerPort = 3000;
var webSocketServer = require('websocket').server;
var http = require('http');

//const app = require('express')();
const path = require('path');
const INDEX = path.join(__dirname, 'index.html');

/*var express = require('express');
var app = express();

app.get('/', function(req, res){
	console.log('hello index page');
  res.sendFile(INDEX);
});

app.get('/messages', function(req, res) {
	console.log('asked for messages');
  res.json(lastMessages);
});*/

/**
 * Global variables
 */

var lastMessages = [];
/**
 * HTTP server
 */
var server = http.createServer(function(request, response) {
  // Not important for us. We're writing WebSocket server,
  // not HTTP server
});
server.listen(webSocketsServerPort, function() {
  console.log((new Date()) + " Server is listening on port "
      + webSocketsServerPort);
});
/**
 * WebSocket server
 */
var wsServer = new webSocketServer({
  // WebSocket server is tied to a HTTP server. WebSocket
  // request is just an enhanced HTTP request. For more info 
  // http://tools.ietf.org/html/rfc6455#page-6
  httpServer: server
});
// This callback function is called every time someone
// tries to connect to the WebSocket server
wsServer.on('request', function(request) {
  console.log((new Date()) + ' Connection from origin ' + request.origin + '.');
  // accept connection - you should check 'request.origin' to
  // make sure that client is connecting from your website
  // (http://en.wikipedia.org/wiki/Same_origin_policy)
  var connection = request.accept(null, request.origin); 
  console.log((new Date()) + ' Connection accepted.');
  
  //send back the sent message
  connection.on('message', function(message) {
    if (message.type === 'utf8') { // accept only text
	console.log('message received: ' + message.utf8Data);
        connection.sendUTF(message.utf8Data);
            /*JSON.stringify({ type:'chat message', data: message.utf8Data }));*/
 
      } else { // log and broadcast the message
        console.log((new Date()) + ' notUtf8 ' + message.utf8Data);        
      }
	 lastMessages.push(message.utf8Data);
  });
  connection.on('close', function(connection) {
      console.log((new Date()) + " Peer "
          + connection.remoteAddress + " disconnected.");
  });
});